﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApplication1.Manager_Controls
{
    public partial class SQLOP : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-SAVEBCL;Initial Catalog=sampleDB;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;
        string id;
        public SQLOP()
        {
            InitializeComponent();
            showDatagrid();

        }
        private void showDatagrid()
        {
            string query = @"SELECT * FROM Info";
            con.Open();
            dt = new DataTable();
            da = new SqlDataAdapter(query,con);
            da.Fill(dt);
            dataGridViewShow.DataSource = dt;
            con.Close();

        }
        private void ClearField()
        {
            textBoxID.Clear();
            textBoxName.Clear();
            textBoxCGPA.Clear();
        }
        private void buttonInsert_Click(object sender, EventArgs e)
        {
            if(textBoxID.Text !="" && textBoxName.Text != "" && textBoxCGPA.Text != "")
            {
                con.Open();
                string query = @"INSERT INTO Info(ID,NAME,CGPA) VALUES(@id,@name,@cgpa)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", textBoxID.Text);
                cmd.Parameters.AddWithValue("@name", textBoxName.Text);
                cmd.Parameters.AddWithValue("@cgpa", textBoxCGPA.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                showDatagrid();
                ClearField();
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text != "")
            {
                con.Open();
                string query = @"UPDATE Info SET NAME = @name, CGPA = @cgpa WHERE ID = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@name", textBoxName.Text);
                cmd.Parameters.AddWithValue("@cgpa", textBoxCGPA.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                showDatagrid();
                ClearField();
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text != "")
            {
                con.Open();
                string query = @"DELETE Info WHERE ID = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", textBoxID.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                showDatagrid();
                ClearField();
            }
        }

        private void dataGridViewShow_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            id = dataGridViewShow.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBoxID.Text = id;
            textBoxName.Text = dataGridViewShow.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxCGPA.Text = dataGridViewShow.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        
    }
}
