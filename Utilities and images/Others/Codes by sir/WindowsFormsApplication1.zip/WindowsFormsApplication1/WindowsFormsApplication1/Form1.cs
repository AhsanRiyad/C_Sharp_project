﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Button b1;
        public Form1()
        {
            InitializeComponent();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString;
            SqlConnection cnn;
            connectionString = @"Data Source=DESKTOP-SAVEBCL;Initial Catalog=sampleDB;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();
            MessageBox.Show("Connection Open  !");
            string query = "Select Password from Credentials where ID = " + textBoxID.Text.ToString() + "AND Password = " + textBoxPass.Text.ToString() ;
            SqlCommand command = new SqlCommand(query,cnn);
            SqlDataAdapter da = new SqlDataAdapter(command);
            string output="" ;
            DataTable dt = new DataTable();
            da.Fill(dt);
            int i = command.ExecuteNonQuery();
            if(dt.Rows.Count > 0)
            {
                
                
                    MessageBox.Show("OK");
                    ManagerForm ob = new ManagerForm();
                    ob.Show();
                
               // MessageBox.Show(output);
            }
            
            dt.Dispose();
            da.Dispose();
            command.Dispose();
            cnn.Close();


            cnn.Close();
            //this.Hide();
            //ManagerForm ob = new ManagerForm();
            //ob.Show();
            
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
