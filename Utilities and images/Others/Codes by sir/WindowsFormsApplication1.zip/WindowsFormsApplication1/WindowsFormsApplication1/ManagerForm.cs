﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Manager_Controls;

namespace WindowsFormsApplication1
{
    public partial class ManagerForm : Form
    {
        public ManagerForm()
        {
            InitializeComponent();
        }

        private void firstPageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelManager.Controls.Clear();
            panelManager.Controls.Add(new File_First_Page());
        }

        private void sendPageFirstItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelManager.Controls.Clear();
            panelManager.Controls.Add(new File_Second_First());
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelManager.Controls.Clear();
            panelManager.Controls.Add(new Helps());
        }

        private void ManagerForm_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void sQLOPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelManager.Controls.Clear();
            panelManager.Controls.Add(new SQLOP());
        }

       
    }
}
